/*
* @Author: Rosen
* @Date:   2017-06-13 19:17:44
* @Last Modified by:   Rosen
* @Last Modified time: 2017-06-13 19:18:13
*/

'use strict';

require('page/common/header/index.js');
require('page/common/nav/index.js');
